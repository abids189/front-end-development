document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.gallery img'); // Select all images in the gallery
    const prevButton = document.getElementById('prevButton'); // Select the 'Previous' button
    const nextButton = document.getElementById('nextButton'); // Select the 'Next' button
    let currentImageIndex = 0; // Initialize the current image index to the first image

    // Function to update the gallery display based on the current image index
    function updateGallery() {
        images.forEach((img, index) => {
            img.style.display = index === currentImageIndex ? 'block' : 'none'; // Show only the current image
        });
    }

    // Event listener for the 'Previous' button
    prevButton.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex - 1 + images.length) % images.length; // Move to the previous image
        updateGallery(); // Update the gallery display
    });

    // Event listener for the 'Next' button
    nextButton.addEventListener('click', () => {
        currentImageIndex = (currentImageIndex + 1) % images.length; // Move to the next image
        updateGallery(); // Update the gallery display
    });

    updateGallery(); // Initial call to display the first image
});
